my game theme is christmas tree decoration theme:

🎄 Welcome to the Christmas Tree Adventure! 🎄

my mission is to decorate the Christmas tree while
navigating exciting challenges. Here's how it works:

💖 Starting Strong:
You start the game with 3 HP (health points).

✨ How to Play:

Collect ornaments and candies:
Ornaments increase your score by 20 points.
Candies not only increase your score by 20 points but also restore 1 HP.

💔 What to Avoid:

Broken ornaments: These decrease your score by 20 points.
The Santa enemy snowman: Avoid snowballs thrown your way, as each hit reduces your score
by 20 points and costs 1 HP.

🎁 Santa's Gift of Protection:
If you're lucky enough to find a gift, it will protect you from the effects of up to 5 broken ornaments.

🏎️ Speed Challenge:

As your score increases, the game speeds up by 5%.
When you’re close to winning (at 200 points), the speed increases by 15% for an extra challenge and the number of avoid entities which in this case the broken ornaments increase

🎅 Victory Condition:
Achieve a score of 300 points to complete the game and successfully decorate the Christmas tree!


🎁🎁🎁🎁🎁🎁🎁🎁🎁
- my first custom feature is creating a new entity (represented by the wrapped gift)the extends rare collect which acts as a protective shield against "5" avoids (broken ornaments).the player can collide with 5 broken ornaments without effecting the HP nor the score
🏎️🏎️🏎️🏎️🏎️🏎️🏎️🏎️🏎️
-my second custom is making the game more challenging, every time the player achieves a score the speed gets incremented by 5% and when they're about to win (when score == 200 since the win score == 300) the speeds increments by 15% and the amount of avoids (broken ornaments) increases, so it's more challenging


win and lose (Similar to the starterGame)
win: 300 score
lose: 0 HP


sources:

- I made the presplash screen on Powerpoint

- the (elf) represnting the player entity:
    https://en.picmix.com/stamp/ChristmasElfNoelLutingifVictoriabea-2542348

- the ornament (collect) entity
    http://www.makefunoflife.net/free-pictures/christmas-ornament-gif-3-created-by-david-hugh-beaumont

- the wrapped gift (new entity (protective shield (santa present)))
    https://giphy.com/sannemakes/tink-a-gift-a-curse

- the candy (rare collect)
    https://giphy.com/gifs/christmas-xmas-navidad-TgKHYRCVGybDbKfbLX

- the snowman enemy (rare avoid)
    https://en.picmix.com/stamp/Snow-Snowman-Snowballs-Snowball-Fight-Winter-Christmas-X-Mas-Gif-JitterBugGirl-1074385

- the angry broken ornaments (avoid)
    https://tenor.com/view/redsketch-griddy-cracked-ornament-gif-14070452248488325889

- the background
    https://wallpapers.com/dark-christmas









